from tkinter import *
from tkinter.ttk import *
from ShuffleCube import ShuffleCube

root = Tk()
root.title("Rubix Cube Shuffler")
root.geometry(str(int(root.winfo_screenwidth()/2))+"x"+str(int(root.winfo_screenheight()/2)))
Header = Label(root, text = "Rubix Cube Shuffler")
Header.pack()
Label(root, text = "").pack()

a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t = 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

MoveArray = [a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t]

Moves = ShuffleCube()
for x in range(len(Moves)):
    MoveArray[x] = Label(root, text = Moves[x])
    MoveArray[x].pack()

def NextShuffle():
    Moves = ShuffleCube()
    for x in MoveArray:
        x.destroy()
    for x in range(len(Moves)):
        MoveArray[x] = Label(root, text = Moves[x])
        MoveArray[x].pack()

NextShuffleButton = Button(root, text = "Shuffle Again", command = NextShuffle)
NextShuffleButton.pack(side="bottom")
ExitButton = Button(root, text = "Exit", command = root.destroy)
#sExitButton.pack()

root.mainloop()
