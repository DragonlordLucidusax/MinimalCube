import random

def ShuffleCube(Moves=20):
	MoveArray = ["U","R","L","D","F","B"]
	PrimeArray = ["'",""]
	ShuffleArray = []
	LastMove = ""
	for x in range(Moves):
		Appended = False
		while Appended == False:
			Move = MoveArray[random.randint(0,5)] + PrimeArray[random.randint(0,1)]
			if Move != LastMove:
				ShuffleArray.append(Move)
				if Move[-1] == "'":
					LastMove = Move[:-2]
				else:
					LastMove = Move + "'"
				Appended = True
	return ShuffleArray

#if __name__ == "__main__":
#	MoveArray = ShuffleCube()
#	for x in MoveArray:
#		print(x)
